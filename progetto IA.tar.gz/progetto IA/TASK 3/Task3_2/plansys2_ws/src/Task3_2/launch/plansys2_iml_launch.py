import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Get the launch directory
    example_dir = get_package_share_directory('Task3_2')
    namespace = LaunchConfiguration('namespace')

    declare_namespace_cmd = DeclareLaunchArgument(
        'namespace',
        default_value='',
        description='Namespace')

    plansys2_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(
            get_package_share_directory('plansys2_bringup'),
            'launch',
            'plansys2_bringup_launch_monolithic.py')),
        launch_arguments={
          'model_file': example_dir + '/pddl/dominioTemporale.pddl',
          'namespace': namespace
          }.items())

    # Specify the actions
    move_cmd = Node(
	package='Task3_2',
	executable='move_action',
	name='move_action',
	namespace=namespace,
	output='screen',
	parameters=[])


    move_carrier_cmd = Node(
        package='Task3_2',
        executable='move_carrier_action',
        name='move_carrier_action',
        namespace=namespace,
        output='screen',
        parameters=[])

    load_carrier_cmd = Node(
        package='Task3_2',
        executable='load_carrier_action',
        name='load_carrier_action',
        namespace=namespace,
        output='screen',
        parameters=[])

    unload_carrier_cmd = Node(
        package='Task3_2',
        executable='unload_carrier_action',
        name='unload_carrier_action',
        namespace=namespace,
        output='screen',
        parameters=[])

    give_content_cmd = Node(
        package='Task3_2',
        executable='give_content_action',
        name='give_content_action',
        namespace=namespace,
        output='screen',
        parameters=[])   # Create the launch description and populate
        
    fill_box_cmd = Node(
        package='Task3_2',
        executable='fill_box_action',
        name='fill_box_action',
        namespace=namespace,
        output='screen',
        parameters=[])
    ld = LaunchDescription()

    ld.add_action(declare_namespace_cmd)

    # Declare the launch options
    ld.add_action(plansys2_cmd)

    ld.add_action(move_cmd)
    ld.add_action(move_carrier_cmd)
    ld.add_action(load_carrier_cmd)
    ld.add_action(unload_carrier_cmd)
    ld.add_action(fill_box_cmd)
    ld.add_action(give_content_cmd)

    return ld
