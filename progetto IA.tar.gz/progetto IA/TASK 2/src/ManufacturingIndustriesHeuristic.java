package fr.uga.pddl4j.heuristics.state;



import fr.uga.pddl4j.planners.statespace.search.Node;

import fr.uga.pddl4j.problem.Problem;
import fr.uga.pddl4j.problem.State;
import fr.uga.pddl4j.problem.operator.Action;
import fr.uga.pddl4j.problem.operator.Condition;







public class ManufacturingIndustriesHeuristic extends RelaxedGraphHeuristic{


   

    
    public ManufacturingIndustriesHeuristic(Problem problem) {
        super(problem);
        super.setAdmissible(false);
       
      
     

    }

    @Override
    public int estimate(final State state, final Condition goal) {
        super.setGoal(goal);
        super.expandRelaxedPlanningGraph(state);
        return super.isGoalReachable() ? 0 : Integer.MAX_VALUE;
    }


 
 
    @Override
    public double estimate(Node node, Condition goal) {
        return estimate((State) node, goal);
    }

    public double estimate ( State state, Condition goal, Action a, double previousEuristic){
        super.setGoal(goal);
        this.expandRelaxedPlanningGraph(state);
        double currheuristic = previousEuristic;
        
        if (a.getName().equals("give-content")){
            currheuristic--;
        }
        else if (a.getName().equals("load-carrier")){
            currheuristic -= 0.5;
        }
        else if (a.getName().equals("fill-box")){
            currheuristic -= 0.5;
        }
        else if (a.getName().equals("move-carrier")){
            currheuristic += 0.1;
        }
        else if (a.getName().equals("move"))
            currheuristic+=0.2;

        return super.isGoalReachable()? currheuristic : Integer.MAX_VALUE;
    }

   

   

   
}



