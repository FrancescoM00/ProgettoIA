/*
 * Copyright (c) 2010 by Damien Pellier <Damien.Pellier@imag.fr>.
 *
 * This file is part of PDDL4J library.
 *
 * PDDL4J is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PDDL4J is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with PDDL4J.  If not, see <http://www.gnu.org/licenses/>
 */

 package fr.uga.pddl4j.planners.statespace;

 import fr.uga.pddl4j.heuristics.state.StateHeuristic;
 import fr.uga.pddl4j.parser.DefaultParsedProblem;
 import fr.uga.pddl4j.parser.Expression;
 import fr.uga.pddl4j.plan.Plan;
 import fr.uga.pddl4j.plan.SequentialPlan;
 import fr.uga.pddl4j.planners.AbstractPlanner;
 import fr.uga.pddl4j.planners.ProblemNotSupportedException;
 import fr.uga.pddl4j.planners.SearchStrategy;
 import fr.uga.pddl4j.planners.statespace.search.ModifiedAStar;
 import fr.uga.pddl4j.planners.statespace.search.Node;
 import fr.uga.pddl4j.planners.statespace.search.StateSpaceSearch;
 import fr.uga.pddl4j.problem.DefaultProblem;
  import fr.uga.pddl4j.problem.Problem;
 import fr.uga.pddl4j.problem.operator.Action;
 
 
 
 import picocli.CommandLine;
  
  
 import java.util.Iterator;
 import java.util.LinkedList;
 import java.util.List;
 
  
  
   
  
  @CommandLine.Command(name = "ML_Planner",
      version = "EslPlanner 2.0",
      description = "Solves a specified planning problem combining A* search "
          + "strategies using own heuristic.",
      sortOptions = false,
      mixinStandardHelpOptions = true,
      headerHeading = "Usage:%n",
      synopsisHeading = "%n",
      descriptionHeading = "%nDescription:%n%n",
      parameterListHeading = "%nParameters:%n",
      optionListHeading = "%nOptions:%n")
  public final class ManufacturingLogisticPlanner extends AbstractPlanner  {
 
     private double weight = 1;
     private int split = 2;
     
       
      @Override
      public Problem instantiate( DefaultParsedProblem problem) {
          DefaultProblem pb = new DefaultProblem(problem);
          pb.instantiate();
          return pb;
      }
      
  
    
      /**
       * Sets the weight of the heuristic.
       *
       * @param weight the weight of the heuristic. The weight must be greater than 0.
       * @throws IllegalArgumentException if the weight is strictly less than 0.
       */
      @CommandLine.Option(names = { "-w", "--weight" }, defaultValue = "1.0", paramLabel = "<weight>",
          description = "Set the weight of the heuristic (preset 1.0).")
      public void setHeuristicWeight(final double weight) {
          this.weight = weight;
      }
 
      @CommandLine.Option(names = { "-s", "--split" }, defaultValue = "1", paramLabel = "<split>",
      description = "Set the split value (preset 1).")
     public void setSplit(final int split) {
         this.split = split;
     }
  
    
 
     @Override
     public Plan solve(Problem problem) throws ProblemNotSupportedException {
 
    
 
         
         Problem[] subProblems = split(problem,split);
         Node[] subSolutions = new Node[subProblems.length];
         Plan[] subplans = new Plan[subProblems.length];
         int timeout = 1000000;
         final long start = System.currentTimeMillis(); 
         SearchStrategy.Name strategyName = SearchStrategy.Name.ASTAR;
         StateHeuristic.Name heuristic = StateHeuristic.Name.MANUFACTURING_INDUSTRIES;
          
         StateSpaceSearch alg0 = StateSpaceSearch.getInstance(strategyName, heuristic, weight);
         subSolutions[0] = alg0.searchSolutionNode(subProblems[0]);
         subplans[0] = alg0.extractPlan(subSolutions[0],subProblems[0]);
 
         //risolviamo i sottoproblemi rimanenti usando AStar customizzato
         for(int i = 1; i<subProblems.length; i++){
             subSolutions[i-1].setParent(null);
             StateSpaceSearch alg = new ModifiedAStar(timeout,heuristic,weight,subSolutions[i-1]);
             subSolutions[i] = alg.searchSolutionNode(subProblems[i]);
             subplans[i] = alg.extractPlan(subSolutions[i],subProblems[i]);
         }
         final long end = System.currentTimeMillis();
         this.getStatistics().setTimeToSearch((end-start));
         List<Action> sol = new LinkedList<>();
         for(Plan p: subplans)
             if(p != null)
                 sol.addAll(p.actions());
         Plan solution = new SequentialPlan();
         Iterator<Action> it = sol.iterator();
         for(int i = 0; i<sol.size(); i++)
             solution.add(i,it.next());
    
     return solution;
  }
 
     
 
    
 
     @SuppressWarnings("unchecked")
     private Problem[] split(Problem problem, int split){
         List<Expression<String>>[] goals = new List[split];
         DefaultParsedProblem pp = problem.getParsedProblem();
         List<Expression<String>> inGoal = pp.getGoal().getChildren();
         int bias = inGoal.size()/split;
         int j = 0;
         Iterator<Expression<String>> it = inGoal.iterator();
         for(int i = 0; i<goals.length; i++){
             goals[i] = new LinkedList<>();
             int k = 0;
             for(;k<bias; k++) {
                 goals[i].add(it.next());
                 it.remove();
             }
             j+=k;
         }
         while(inGoal.size()>0)
             for(int k = 0; k<goals.length; k++) {
                 goals[k].add(inGoal.remove(0));
                 if(inGoal.isEmpty())break;
             }
         Problem[] ret = new DefaultProblem[split];
         for(int i = 0; i<ret.length; i++){
             Expression<String> tmp = new Expression<>();
             tmp.setChildren(goals[i]);
             System.out.println("Goal"+i+": "+tmp);
             pp.setGoal(tmp);
             ret[i] = new DefaultProblem(pp);
             ret[i].instantiate();
         }
         return ret;
     }
 
     @Override
     public boolean isSupported(Problem problem) {
         return true;
     }
  
     /*  
       *
       * @param args the arguments of the command line.
       */
       public static void main(String[] args) {
         try {
             final ManufacturingLogisticPlanner planner = new ManufacturingLogisticPlanner();
             CommandLine cmd = new CommandLine(planner);
             int exitCode = (int) cmd.execute(args);
             if (exitCode == 1) {
                 System.out.println(cmd.getUsageMessage());
             }
             System.exit(exitCode);
         } catch (Throwable e) {
             System.err.println(e.getMessage());
         }
     }
 
    
  }